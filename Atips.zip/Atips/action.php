<?php
session_start();
include 'db.php';

//add user
if (isset($_POST['signup'])) {
    $first = $_POST['fname'];
    $last = $_POST['lname'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $repassword = $_POST['repass'];
    $contact = $_POST['contact'];

    $date = date('Y-m-d');

    if (empty($first) || empty($last) || empty($email) || empty($password) || empty($repassword) || empty($contact)) {
        $_SESSION['error'] = 'Please fill in the form';
        header('location: users.php');

    } else {
        if (strlen($password) < 8) {
            $_SESSION['error'] = 'Password is weak';
            header('location: users.php');
            exit;
        }
        if ($password != $repassword) {
            $_SESSION['error'] = 'Passwords dont match';
            header('location: users.php');
            exit;
        }

        //existing email address in our database
        $sql = "SELECT user_id FROM users WHERE email = '$email' LIMIT 1";
        $check_query = mysqli_query($con, $sql);
        $count_email = mysqli_num_rows($check_query);
        if ($count_email > 0) {
            $_SESSION['error'] = 'Email already exists';
            header('location:users.php');

        } else {

            $sql = "INSERT INTO `users` 
		(`user_id`, `fname`, `lname`, `email`, 
		`password`,`contact`,`created_on`) 
		VALUES (NULL, '$first', '$last', '$email', 
		'$password','$contact','$date')";
            $run_query = mysqli_query($con, $sql);

            if ($run_query) {
                echo 'User has been registered successfully';
                header('location:login.php');
            }
        }
    }
}

// edit user
if (isset($_POST['edituser'])) {
    $id = $_POST['id'];
    $first = $_POST['firstname'];
    $last = $_POST['lastname'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $repassword = $_POST['repassword'];
    $subscription = $_POST['subscription'];
    $contact = $_POST['contact'];

    $date = date('Y-m-d');

    if (empty($first) || empty($last) || empty($email) || empty($password) || empty($repassword) || empty($subscription) || empty($contact)) {
        $_SESSION['error'] = 'Please fill in the form';
        header('location: users.php');

    } else {
        if (strlen($password) < 8) {
            $_SESSION['error'] = 'Password is weak';
            header('location: users.php');
            exit;
        }
        if ($password != $repassword) {
            $_SESSION['error'] = 'Passwords dont match';
            header('location: users.php');
            exit;
        }
        else {

            $sql = "UPDATE users SET `fname`= '$first',`lname` = '$last',`email` = '$email',`password` = '$password',`subscription`='$subscription',`contact`='$contact' WHERE user_id = '$id' ";

            $run_query = mysqli_query($con, $sql);

            if ($run_query) {
                $_SESSION['success'] = 'User has been updated successfully';
                header('location:users.php');
            }
            else{
                $_SESSION['error'] = 'User has not been updated successfully';
                header('location:users.php');
            }
        }
    }
}

//user login
if (isset($_POST['login'])){
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE email = '$email'AND password = '$password'";
    $run_query = mysqli_query($con,$sql);
    $count = mysqli_num_rows($run_query);
    $row = mysqli_fetch_array($run_query);
    $_SESSION["uid"] = $row["user_id"];
    $_SESSION["name"] = $row["fname"];
    $sub=$row['subscription'];

    if(empty($email) || empty($password)){
        $_SESSION['error'] = 'Fill in the form first';
        header('location:login.php');
    }
    else{
        if ($count == 1){
            echo 'login_success';
            if($sub < 1){
                header('location: subscribe.php');
            }
            else{
                header('location: home.php');
            }
            
        }
        else{
            $_SESSION['error'] = 'Incorrect login credentials';
            header('location:login.php');
        }
    }
}
//logout

if (isset($_POST['logout'])){
    unset($_SESSION['uid']);
    unset($_SESSION['name']);

    header('location:login.php');
}

//subscription

if (isset($_POST['pay'])) {
    $id=$_POST['id'];
    $sid = $_POST['sub'];
    $code=$_POST['code'];
    $amount=$_POST['amount'];
    $cash=$_POST['cash'];
    $date = date('Y-m-d');

    if($code!=12345){
        $_SESSION['error'] = 'Invalid code <a href="pay.php?id='.$sid.'">Back</a> ';
        header('location:confirm.php');
        exit();
    }
    if($cash!=$amount){
        $_SESSION['error'] = 'Invalid amount <a href="pay.php?id='.$sid.'">Back</a> ';
        header('location:confirm.php');
        exit();
    }
    $sql = "UPDATE users SET `subscription`='$sid',`sub_date`='$date' WHERE user_id = '$id' ";

    $run_query = mysqli_query($con, $sql);

    if ($run_query) {
        $_SESSION['success'] = 'Subscription successfully,<a href="login.php">Login to dashboard</a>';
        header('location:confirm.php');
    }
    else{
        $_SESSION['error'] = 'Subscription not successfully,<a href="subscribe.php">Go to Subscription</a>';
        header('location:confirm.php');
    }
        
}