<?php

session_start();
if (!isset($_SESSION['uid'])){
    header('location:login.php');
}

include"includes/header.php";
include"db.php";

?>

<?php
$user=$_SESSION['uid'];
$sql = "SELECT * FROM users WHERE user_id='$user'";
$query = mysqli_query($con, $sql);
$row = mysqli_fetch_array($query);

?>

<body data-spy="scroll" data-target="#pb-navbar" data-offset="200">



	<nav class="navbar navbar-expand-lg site-navbar navbar-light bg-light" id="pb-navbar">

		<div class="container">
			<img class="img-rounded" style="width: 50px; height: 50px;" src="images/ATIPS.jpg">
            <div class="navbar-brand">
                <h2>ATIPS</h2>
            </div>

			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample09" aria-controls="navbarsExample09" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>


			<div class="collapse navbar-collapse justify-content-md-center" id="navbarsExample09">
				<ul class="navbar-nav">
					<li class="nav-item"><a class="nav-link" href="#section-home">Home</a></li>
					<li class="nav-item"><a class="nav-link" href="#section-services">Profile</a></li>
					<li class="nav-item"><a class="nav-link" href="#section-about">Tips</a></li>
					<li class="nav-item"><a class="nav-link" href="#section-contact">Contact</a></li>
				</ul>
			</div>
		</div>
	</nav>




	<section class="site-hero" style="background-image: url(images/r4.jpg);" id="section-home" data-stellar-background-ratio="0.5">
		<div class="container">
			<div class="row intro-text align-items-center justify-content-center">
				<div class="col-md-10 text-center pt-5">

					<h1 class="site-heading site-animate"> <strong class="d-block">WELCOME <?php echo $row['fname']?> TO ATIPS 2+ODDS. LETS GET YOU SERVED.</strong></h1>
					<strong class="d-block text-white text-uppercase letter-spacing">DAILY 2+ ODDS...</strong>

				</div>
			</div>
		</div>
	</section> <!-- section -->



	
	<section class="site-section " id="section-services">
        <div class="container">

			<div class="row mb-4">
				<div class="col-md-12">
					<div class="section-heading text-center">
						<h2>Your <strong>Profile</strong></h2>
					</div>
				</div>
			</div>
			<div class="row">

				<div class="col-md-6 col-lg-5 text-center mb-5">
					<div class="site-service-item site-animate" data-animate-effect="fadeIn">
						<span class="icon">
							<span class="icon-wallet2"></span>
						</span>
						<h3 class="mb-4"><?php echo $row['fname'].' '. $row['lname']?></h3>
						<p>Email: <?php echo $row['email']?></p>
                        <p>Contact: <?php echo $row['contact']?></p>
                        <form action="action.php" method="post">
                            <p><input type="submit" name="logout" class="site-link" value="Logout"></p>
                        </form>
					</div>
				</div>
				<div class="col-md-6 col-lg-5 text-center mb-5">
					<div class="site-service-item site-animate" data-animate-effect="fadeIn">
						<span class="icon">
							<span class="icon-wallet2"></span>
						</span>
						<h3 class="mb-4">Current Subscription</h3>
						<p>
                            <?php
                                $sub = $row['subscription'];
                                $run = mysqli_query($con, "SELECT * FROM subscription WHERE sub_id='$sub'");
                                $fetch = mysqli_fetch_array($run);
                                $type = $fetch['type'];
                                
                                echo"$type subscription";
                                 
                            ?>
                        </p>
						<p><a href="#" class="site-link text-success">Subscribed <i class="icon-chevron-right"></i></a></p>
					</div>
				</div>
			</div>
		</div>
	</section> 
	<!-- .section -->

	<section class="site-section" id="section-about">
		<div class="container">
			<div class="row mb-5 align-items-center">
				<div class="col-lg-7 pr-lg-5 mb-5 mb-lg-0">
					<img src="images/meet.jpg" alt="Image placeholder" class="img-fluid">
				</div>
				<div class="col-lg-5 pl-lg-5">
					<div class="section-heading">
						<h2>Today's <strong>tips</strong></h2>
					</div>
					<div class="resume-item mb-4">
                        <?php
                            $now = date('Y-m-d'); 
                        ?>
                        <span class="date"><span class="icon-calendar"></span> <?php echo $now?></span>
                        <?php
                            $query = mysqli_query($con, "SELECT * FROM pick WHERE date='$now'") or die(mysqli_error());
                            while($fetch = mysqli_fetch_array($query)){
                        ?>
                        
                            <?php 
                                $match= $fetch['match_id'];
                                $sql = mysqli_query($con, "SELECT * FROM game WHERE match_id='$match'");
                                while ($row = mysqli_fetch_array($sql)) {
                                    $home= $row['home'];
                                    $away=$row['away'];
                                    $lea=$row['league'];

                                    $ql = mysqli_query($con, "SELECT * FROM league WHERE league_id='$lea'");
                                    while ($wr = mysqli_fetch_array($ql)) {
                                        $league=$wr['league_name'];
                                    }
                                    ?>
                                    <h3><?php echo $league?> </h3>
                            <p> 
                                    <?php

                                    $sl = mysqli_query($con, "SELECT * FROM teams WHERE team_id='$home'");
                                    while ($rw = mysqli_fetch_array($sl)) {
                                        $hm=$rw['team_name'];
                                    }
                                    
                                    $sq = mysqli_query($con, "SELECT * FROM teams WHERE team_id='$away'");
                                    while ($ro = mysqli_fetch_array($sq)) {
                                        $aw= $ro['team_name'];
                                    }
                                    echo"$hm vs $aw";
                                }
                                
                            ?>
                            <br>
                            <?php 
                                $tip= $fetch['tip_id'];
                                $sql = mysqli_query($con, "SELECT * FROM tips WHERE tip_id='$tip'");
                                while ($row = mysqli_fetch_array($sql)) {
                                    $t = $row['name'];
                                    echo"Pick: $t";
                                }
                            ?> 
                            <span class="school text-success">
                            <?php 
                                $odds=$fetch['odds'];
                                echo "Odds: $odds"; 
                            ?>
                            </span>

                        </p>
                        
                        <?php
                            }
                        ?>
                        <hr>
                        <h3>Total odds:2.3</h3>
                    </div>
				</div>
			</div>


		</div>
	</section>
	<section class="site-section pb-0">

		<!-- previous tips  section -->
	<section class="top-letest-product-section">
		<div class="container">
			<div class="col-md-12">
				<div class="section-heading text-center">
					<h2>Previous <strong>Tips</strong></h2>
				</div>
			</div>
			<div class="product-slider owl-carousel">
				<div class="product-item">
					<div class="pi-pic">
						<div class="resume-item mb-4">
						<?php
							$now=date('Y-m-d');
							$query = mysqli_query($con, "SELECT * FROM pick WHERE date < '$now' ORDER BY date DESC LIMIT 1") or die(mysqli_error());
							while($fetch = mysqli_fetch_array($query)){
								$date=$fetch['date'];
						?>
						
						<span class="date"><span class="icon-calendar"></span> <?php echo $date ?></span>
						<?php 
                                $match= $fetch['match_id'];
                                $sql = mysqli_query($con, "SELECT * FROM game WHERE match_id='$match'");
                                while ($row = mysqli_fetch_array($sql)) {
                                    $home= $row['home'];
                                    $away=$row['away'];
                                    $lea=$row['league'];

                                    $ql = mysqli_query($con, "SELECT * FROM league WHERE league_id='$lea'");
                                    while ($wr = mysqli_fetch_array($ql)) {
                                        $league=$wr['league_name'];
                                    }
                                    ?>
                                    <h3><?php echo $league?> </h3>
                            <p> 
                                    <?php

                                    $sl = mysqli_query($con, "SELECT * FROM teams WHERE team_id='$home'");
                                    while ($rw = mysqli_fetch_array($sl)) {
                                        $hm=$rw['team_name'];
                                    }
                                    
                                    $sq = mysqli_query($con, "SELECT * FROM teams WHERE team_id='$away'");
                                    while ($ro = mysqli_fetch_array($sq)) {
                                        $aw= $ro['team_name'];
                                    }
                                    echo"$hm vs $aw";
                                }
                                
                            ?>
                            <br>
                            <?php 
                                $tip= $fetch['tip_id'];
                                $sql = mysqli_query($con, "SELECT * FROM tips WHERE tip_id='$tip'");
                                while ($row = mysqli_fetch_array($sql)) {
                                    $t = $row['name'];
                                    echo"Pick: $t";
                                }
                            ?> 
                            <span class="school text-success">
                            <?php 
                                $odds=$fetch['odds'];
                                echo "Odds: $odds"; 
                            ?>
                            </span>

                        </p>
                        
                        <?php
                            }
                        ?>
                        <hr>
                        <h3>Total odds:2.3</h3>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- previous tips section end -->
		
	</section>


	<section class="site-section" id="section-contact">
		<div class="container">
			<div class="row">
				<div class="col-md-12 mb-5">
					<div class="section-heading text-center">
						<h2>Get <strong>In Touch</strong></h2>
					</div>
				</div>

				<div class="col-md-7 mb-5 mb-md-0">
					<form action="" class="site-form">
						<h3 class="mb-5">Get In Touch</h3>
						<div class="form-group">
							<input type="text" class="form-control px-3 py-4" placeholder="Your Name">
						</div>
						<div class="form-group">
							<input type="email" class="form-control px-3 py-4" placeholder="Your Email">
						</div>
						<div class="form-group">
							<input type="email" class="form-control px-3 py-4" placeholder="Your Phone">
						</div>
						<div class="form-group mb-5">
							<textarea class="form-control px-3 py-4"cols="30" rows="10" placeholder="Write a Message"></textarea>
						</div>
						<div class="form-group">
							<input type="submit" class="btn btn-primary  px-4 py-3" value="Send Message">
						</div>
					</form>
				</div>
				<div class="col-md-5 pl-md-5">
					<h3 class="mb-5">Contact Details</h3>
					<ul class="site-contact-details">
						<li>
							<span class="text-uppercase">Email</span>
							atipsodds@gmail.com
						</li>
						<li>
							<span class="text-uppercase">Phone</span>
							Call , Whatsapp , telegram <br>
							@ +254 771595715
						</li>
						
					</ul>
				</div>
			</div>
		</div>
    </section>
    
<?php
include"includes/footer.php";
include"includes/scripts.php";
?>