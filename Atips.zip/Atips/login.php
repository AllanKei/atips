<?php
include"includes/header.php";
?>

<body data-spy="scroll" data-target="#pb-navbar" data-offset="200">

    <section class="site-section " id="section-services">
        <div class="container">

			<div class="row mb-4">
				<div class="col-md-12">
					<div class="section-heading text-center">
						<h2> <strong>Login Form</strong></h2>
					</div>
				</div>
			</div>
			<div class="row justify-content-center">
				<div class="col-md-6 col-lg-4 text-center mb-5">
					<div class="site-service-item site-animate" data-animate-effect="fadeIn">
                        
                        <form class="site-form" action="action.php" method="post">
                            <h3 class="mb-5">Welcome Back!</h3>
                            <div class="form-group">
                                <input type="email" name="email" class="form-control px-3 py-4" placeholder="Email Address...">
                            </div>
                            <div class="form-group">
                                <input type="password" name="password" class="form-control px-3 py-4" placeholder="Password">
                            </div>
                        
                            <input class="btn btn-primary btn-user btn-block" type="submit" name="login" value="Login">

                            <hr>
                            
						  </form>
						  	<div class="text-center">
								<a  href="#">Forgot Password?</a>
							</div>
							<div class="text-center">
								<a  href="signup.php">Create an Account!</a>
							</div>
							<div class="text-center">
								<a  href="index.php">Home</a>
							</div>

					</div>
				</div>
			</div>
		</div>
	</section> 

</body>
</html>