<?php
session_start();
if (!isset($_SESSION['uid'])){
    header('location:login.php');
}

include"includes/header.php";
include"db.php";
?>

<body data-spy="scroll" data-target="#pb-navbar" data-offset="200">



	<nav class="navbar navbar-expand-lg site-navbar navbar-light bg-light" id="pb-navbar">

		<div class="container">
            <div class="navbar-brand">
                <h2>ATIPS</h2>
            </div>

		</div>
	</nav>


	
	<section class="site-section " id="section-services">
        <div class="container">

			<div class="row mb-4">
				<div class="col-md-12">
					<div class="section-heading text-center">
						<h2> <strong>Payment</strong></h2>
					</div>
				</div>
			</div>
			<div class="row justify-content-center">
                <?php
                   $subid = $_GET['id'];
                   $user = $_SESSION['uid'];
                   $query = mysqli_query($con, "SELECT * FROM subscription WHERE sub_id = $subid") or die(mysqli_error());
                   $fetch = mysqli_fetch_array($query);
                    $type=$fetch['type'];
                    $price=$fetch['price'];
                   
                ?>
                <div class="col-md-6 col-lg-4 text-center mb-5">
					<div class="site-service-item site-animate" data-animate-effect="fadeIn">
                        <h3 class="mb-4"><?php echo $type?> Subscription</h3>
						<p>Pay Ksh <?php echo $price?> to 0726002003(Allan Langat)</p>
                        <form class="site-form" action="action.php" method="post">
                            <h3 class="mb-5">Enter Mpesa payment details <?php echo $subid?>!</h3>
                            <div class="form-group">
                                <input type="hidden" name="id" value="<?php echo $user?>">
                                <input type="hidden" name="sub" value="<?php echo $subid?>">
                                <input type="hidden" name="amount" value="<?php echo $price?>">
                                <input type="text" name="code" class="form-control px-3 py-4" placeholder="Transaction code...">
                            </div>
                            <div class="form-group">
                                <input type="number" name="cash" class="form-control px-3 py-4" placeholder="Amount..">
                            </div>
                        
                            <input class="btn btn-primary btn-user btn-block" type="submit" name="pay" value="Confirm">

                            <hr>
                            
                        </form>
					</div>
				</div>
			</div>
		</div>
    </section> 
    <?php
    include"includes/scripts.php";
    ?>