<!-- edit team-->
<div class="modal fade" id="editsub<?php echo $fetch['sub_id']?>">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edit <?php echo $fetch['type']?> subscription</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" method="POST" action="action.php" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="name" class="col-sm-3 control-label" >Subscription Type</label>

                        <div class="col-sm-5">
                            <input type="hidden" name="id" value="<?php echo $fetch['sub_id']?>">
                            <input type="text" class="form-control" id="name" name="name" value="<?php echo $fetch['type']?>" required>
                        </div>

                    </div>
                    <div class="form-group">
                        <label for="name" class="col-sm-3 control-label" >Price</label>

                        <div class="col-sm-5">
                            <input type="number" class="form-control" id="price" name="price" value="<?php echo $fetch['price']?>" required>
                        </div>

                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
                <button type="submit" class="btn btn-primary btn-flat" name="editsub"><i class="fa fa-save"></i> Save</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Delete team -->
<div class="modal fade" id="deletesub<?php echo $fetch['sub_id']?>">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Delete <?php echo $fetch['type']?> subscription</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Do you want to delete <?php echo $fetch ['type']?> subscription?</div>
            <div class="modal-footer">
                <form action="action.php" method="post">
                    <input type="hidden" name="id" value="<?php echo $fetch ['sub_id']?>">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <button class="btn btn-danger" type="submit" name="delsub">Delete</button>
                </form>

            </div>
        </div>
    </div>
</div>