<?php
include 'db.php';
include 'includes/header.php';
include 'includes/sidebar.php';
include 'includes/navbar.php';

?>
<!-- Begin Page Content -->
<div class="container-fluid">

    <div class="container-fluid">
        <h3 class="mt-4 text-gray-600">Featured picks</h3>
        <h6 class="mt-4 text-gray-700">
            <?php 
                $sql ="SELECT * FROM pk";
                $query =mysqli_query($con,$sql);
                $row = mysqli_fetch_array($query); 
                $kid=$row['key_id'];
                $date=$row['date'];
            ?>
            Key Id: <?php echo $kid ?><br>
            Date: <?php echo $date ?>
        </h6>
        <button data-toggle="modal" data-target="#key"> Update key</button>
    </div>
    <br>
    <?php

    if(isset($_SESSION['error'])){
        echo "
          <div class='alert alert-danger text-center'>
          <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
            <p>".$_SESSION['error']."</p> 
          </div>
        ";
        unset($_SESSION['error']);
    }

    if(isset($_SESSION['success'])){
        echo "
          <div class='alert alert-success text-center'>
          <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
            <p>".$_SESSION['success']."</p> 
          </div>
        ";
        unset($_SESSION['success']);
    }
    ?>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Picks</h6>
            <button class=" float-right" data-toggle="modal" data-target="#addPick"><i class="fa fa-plus"></i> Add pick</button>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Match id</th>
                        <th>Tip id</th>
                        <th>Key</th>
                        <th>Odds</th>
                        <th>Date</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $n=0;
                    $n++;
                    $query = mysqli_query($con, "SELECT * FROM pick") or die(mysqli_error());
                    while($fetch = mysqli_fetch_array($query)){

                    ?>
                    <tr>
                        <td><?php echo $n++ ?></td>
                        <td>
                            <?php 
                                $match= $fetch['match_id'];
                                $sql = mysqli_query($con, "SELECT * FROM game WHERE match_id='$match'");
                                while ($row = mysqli_fetch_array($sql)) {
                                    $home= $row['home'];
                                    $away=$row['away'];
                                    $sl = mysqli_query($con, "SELECT * FROM teams WHERE team_id='$home'");
                                    while ($rw = mysqli_fetch_array($sl)) {
                                        $hm=$rw['team_name'];
                                    }
                                    
                                    $sq = mysqli_query($con, "SELECT * FROM teams WHERE team_id='$away'");
                                    while ($ro = mysqli_fetch_array($sq)) {
                                        $aw= $ro['team_name'];
                                    }
                                    echo"$hm vs $aw";
                                }
                                
                            ?>
                        </td>
                        <td>
                            <?php 
                                $tip= $fetch['tip_id'];
                                $sql = mysqli_query($con, "SELECT * FROM tips WHERE tip_id='$tip'");
                                while ($row = mysqli_fetch_array($sql)) {
                                    $t = $row['name'];
                                    echo $t;
                                }
                            ?>
                        </td>
                        <td>
                            <?php $sku = $fetch['sku'];
                                echo $sku;
                            ?>
                        </td>
                        <td>
                            <?php 
                                $odds=$fetch['odds'];
                                echo $odds; 
                            ?>
                        </td>
                        <td><?php echo $fetch['date'] ?></td>
                        <td>
                            <a href="#"  data-toggle="modal" type="button" data-target="#editpick<?php echo $fetch['pick_id']?>" title="edit"><i class="fas fa-edit fa-lg text-success mr-2"></i></a>
                            <p></p>
                            <a href="#" data-toggle="modal" type="button" data-target="#deletepick<?php echo $fetch['pick_id']?>" title="delete"><i class="fas fa-trash-alt fa-lg text-danger"></i></a>
                        </td>
                    </tr>
                    <?php
                    include"editpick.php";
                    }
                    ?>


                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>

<!-- Update key -->
<div class="modal fade" id="key">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Update Key</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" method="POST" action="action.php" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="name" class="col-sm-3 control-label" >Key Id</label>
                        
                        <?php
                            $sql = mysqli_query($con, "SELECT * FROM pk");
                            $row = mysqli_fetch_array($sql);
                            $id=$row['id'];
                            $key= $row['key_id'];
                            
                        ?>

                        <div class="col-sm-5">
                            <input type="hidden" class="form-control" id="id" name="id" value="<?php echo $id ?>" required>
                            <input type="number" class="form-control" id="ky" name="ky" value="<?php echo $key ?>" required>
                        </div>

                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
                <button type="submit" class="btn btn-primary btn-flat" name="key"><i class="fa fa-save"></i> Save</button>
                </form>
            </div>
        </div>
    </div>
</div>


<!-- /.container-fluid -->
<?php
include 'includes/scripts.php';
include 'includes/modal.php';