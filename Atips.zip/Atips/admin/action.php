<?php
session_start();
include 'db.php';
//add team
if (isset($_POST['addTeam'])){
    $name = $_POST['name'];

    $sql = "INSERT INTO teams (`team_id`, `team_name`) VALUES(NULL,'$name') ";
    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Team added successfully';
        header('location:team.php');
    }
    else{
        $_SESSION['error']='Team not added successfully';
        header('location:team.php');
    }
}
//edit team
if (isset($_POST['editteam'])){
    $id = $_POST['id'];
    $name = $_POST['name'];
    $sql = "UPDATE teams SET `team_name`= '$name' WHERE team_id ='$id'";
    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Team updated successfully';
        header('location:team.php');
    }
    else{
        $_SESSION['error']='Team not updated successfully';
        header('location:team.php');
    }
}
//delete team
if (isset($_POST['delteam'])){
    $id = $_POST['id'];

    $sql= "DELETE FROM teams WHERE team_id = '$id'";

    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Team deleted successfully';
        header('location:team.php');
    }
    else{
        $_SESSION['error']='Team not deleted successfully';
        header('location:team.php');
    }
}

//add tip
if (isset($_POST['addTip'])){
    $name = $_POST['name'];

    $sql = "INSERT INTO tips (`tip_id`, `name`) VALUES(NULL,'$name') ";
    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Tip added successfully';
        header('location:tips.php');
    }
    else{
        $_SESSION['error']='Tip not added successfully';
        header('location:tips.php');
    }
}
//edit tip
if (isset($_POST['edittip'])){
    $id = $_POST['id'];
    $name = $_POST['name'];
    $sql = "UPDATE tips SET `name`= '$name' WHERE tip_id ='$id'";
    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Tip updated successfully';
        header('location:tips.php');
    }
    else{
        $_SESSION['error']='Tip not updated successfully';
        header('location:tips.php');
    }
}
//delete tip
if (isset($_POST['deltip'])){
    $id = $_POST['id'];

    $sql= "DELETE FROM tips WHERE tip_id = '$id'";

    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Tip deleted successfully';
        header('location:tips.php');
    }
    else{
        $_SESSION['error']='Tip not deleted successfully';
        header('location:tips.php');
    }
}

//add league
if (isset($_POST['addLeague'])){
    $name = $_POST['name'];

    $sql = "INSERT INTO league (`league_id`, `league_name`) VALUES(NULL,'$name') ";
    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='League added successfully';
        header('location:league.php');
    }
    else{
        $_SESSION['error']='League not added successfully';
        header('location:league.php');
    }
}
//edit league
if (isset($_POST['editlea'])){
    $id = $_POST['id'];
    $name = $_POST['name'];
    $sql = "UPDATE league SET `league_name`= '$name' WHERE league_id ='$id'";
    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='League updated successfully';
        header('location:league.php');
    }
    else{
        $_SESSION['error']='League not updated successfully';
        header('location:league.php');
    }
}
//delete league
if (isset($_POST['dellea'])){
    $id = $_POST['id'];

    $sql= "DELETE FROM league WHERE league_id = '$id'";

    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='League deleted successfully';
        header('location:league.php');
    }
    else{
        $_SESSION['error']='League not deleted successfully';
        header('location:league.php');
    }
}

//add subscription
if (isset($_POST['addSub'])){
    $type = $_POST['type'];
    $price = $_POST['price'];

    $sql = "INSERT INTO subscription (`sub_id`,`type`,`price`) VALUES(NULL,'$type','$price') ";
    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Subscription added successfully';
        header('location:subscription.php');
    }
    else{
        $_SESSION['error']='Subscription not added successfully';
        header('location:subscription.php');
    }
}
//edit subscription
if (isset($_POST['editsub'])){
    $id = $_POST['id'];
    $name = $_POST['name'];
    $price= $_POST['price'];

    $sql = "UPDATE subscription SET `type`= '$name', `price`='$price' WHERE sub_id ='$id'";
    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Subscription updated successfully';
        header('location:subscription.php');
    }
    else{
        $_SESSION['error']='Subscription not updated successfully';
        header('location:subscription.php');
    }
}
//delete subscription

if (isset($_POST['delsub'])){
    $id = $_POST['id'];

    $sql= "DELETE FROM subscription WHERE sub_id = '$id'";

    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Subscription deleted successfully';
        header('location:subscription.php');
    }
    else{
        $_SESSION['error']='Subscription not deleted successfully';
        header('location:subscription.php');
    }
}

//add match
if (isset($_POST['addMatch'])){
    $home = $_POST['home'];
    $away = $_POST['away'];
    $league = $_POST['league'];
    $date = date('Y-m-d');

    $sql = "INSERT INTO game (`match_id`, `home`,`away`,`league`,`date`) VALUES(NULL,'$home','$away','$league','$date') ";
    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Match added successfully';
        header('location:match.php');
    }
    else{
        $_SESSION['error']='Match not added successfully';
        header('location:match.php');
    }
}
//edit match
if (isset($_POST['editmatch'])){
    $id = $_POST['id'];
    $home = $_POST['home'];
    $away= $_POST['away'];
    $league = $_POST['league'];

    $sql = "UPDATE game SET `home`= '$home', `away`='$away', `league`='$league' WHERE match_id ='$id'";
    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Match updated successfully';
        header('location:match.php');
    }
    else{
        $_SESSION['error']='Match not updated successfully';
        header('location:match.php');
    }
}
//delete match

if (isset($_POST['delmatch'])){
    $id = $_POST['id'];

    $sql= "DELETE FROM game WHERE match_id = '$id'";

    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Match deleted successfully';
        header('location:match.php');
    }
    else{
        $_SESSION['error']='Match not deleted successfully';
        header('location:match.php');
    }
}

//add pick
if (isset($_POST['addPick'])){
    $match = $_POST['match'];
    $tip = $_POST['tip'];
    $key = $_POST['sku'];
    $odds = $_POST['odds'];
    $date = date('Y-m-d');

    $sql = "INSERT INTO pick (`pick_id`, `match_id`,`tip_id`,`sku`,`odds`,`date`) VALUES(NULL,'$match','$tip','$key','$odds','$date') ";
    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Pick added successfully';
        header('location:pick.php');
    }
    else{
        $_SESSION['error']='Pick not added successfully';
        header('location:pick.php');
    }
}
//edit pick
if (isset($_POST['editpick'])){
    $id = $_POST['id'];
    $match = $_POST['match'];
    $tip = $_POST['tip'];
    $key = $_POST['sku'];
    $odds = $_POST['odds'];

    $sql = "UPDATE pick SET `match_id`= '$match', `tip_id`='$tip', `sku`='$key',`odds`='$odds' WHERE pick_id ='$id'";
    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Pick updated successfully';
        header('location:pick.php');
    }
    else{
        $_SESSION['error']='Pick not updated successfully';
        header('location:pick.php');
    }
}
//delete pick

if (isset($_POST['delpick'])){
    $id = $_POST['id'];

    $sql= "DELETE FROM pick WHERE pick_id = '$id'";

    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Pick deleted successfully';
        header('location:pick.php');
    }
    else{
        $_SESSION['error']='Pick not deleted successfully';
        header('location:pick.php');
    }
}

//update key
if (isset($_POST['key'])){
    $id = $_POST['id'];
    $key = $_POST['ky'];
    $date = date('Y-m-d');

    $sql = "UPDATE pk SET `key_id`= '$key', `date`='$date' WHERE id ='$id'";
    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Key updated successfully';
        header('location:pick.php');
    }
    else{
        $_SESSION['error']='Key not updated successfully';
        header('location:pick.php');
    }
}

//register admin
if (isset($_POST['register'])) {
    $first = $_POST['firstname'];
    $last = $_POST['lastname'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $repassword = $_POST['repassword'];
    $contact = $_POST['contact'];

    $date = date('Y-m-d');

    if (empty($first) || empty($last) || empty($email) || empty($password) || empty($repassword) || empty($contact)) {
        $_SESSION['error'] = 'Please fill in the form';
        header('location: signup.php');

    } else {
        if (strlen($password) < 8) {
            $_SESSION['error'] = 'Password is weak';
            header('location: signup.php');
            exit;
        }
        if ($password != $repassword) {
            $_SESSION['error'] = 'Passwords dont match';
            header('location: signup.php');
            exit;
        }

        //existing email address in our database
        $sql = "SELECT admin_id FROM admin WHERE email = '$email' LIMIT 1";
        $check_query = mysqli_query($con, $sql);
        $count_email = mysqli_num_rows($check_query);
        if ($count_email > 0) {
            $_SESSION['error'] = 'Email already exists, <a href="login.php">login</a> instead';
            header('location:signup.php');

        } else {

            $sql = "INSERT INTO `admin` 
		(`admin_id`, `fname`, `lname`, `email`, 
		`password`,`contact`,`created_at`) 
		VALUES (NULL, '$first', '$last', '$email', 
		'$password','$contact','$date')";
            $run_query = mysqli_query($con, $sql);
            $_SESSION["uid"] = mysqli_insert_id($con);
            $_SESSION["name"] = $first;

            $ip_add = getenv("REMOTE_ADDR");
            if ($run_query) {

                header('location: login.php');
                exit;
            }
        }
    }
}

//edit admin
if (isset($_POST['editadmin'])) {
    $id = $_POST['id'];
    $first = $_POST['firstname'];
    $last = $_POST['lastname'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $repassword = $_POST['repassword'];
    $contact = $_POST['contact'];


    if (empty($first) || empty($last) || empty($email) || empty($password) || empty($repassword) || empty($contact)) {
        $_SESSION['error'] = 'Please fill in the form';
        header('location: profile.php');

    } else {
        if (strlen($password) < 8) {
            $_SESSION['error'] = 'Password is weak';
            header('location: profile.php');
            exit;
        }
        if ($password != $repassword) {
            $_SESSION['error'] = 'Passwords dont match';
            header('location: profile.php');
            exit;
        }
        $sql = "UPDATE admin SET `fname`= '$first',`lname` = '$last',`email` = '$email',`password` = '$password',`contact`='$contact' WHERE admin_id = '$id' ";
        $run_query = mysqli_query($con, $sql);
        if ($run_query) {
            $_SESSION['success'] = 'Profile updated successfully';
            header('location:profile.php');
        } else {
            $_SESSION['error'] = 'Profile not updated successfully';
            header('location:profile.php');
        }
    }
}

//admin login
if (isset($_POST['login'])){
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM admin WHERE email = '$email'AND password = '$password'";
    $run_query = mysqli_query($con,$sql);
    $count = mysqli_num_rows($run_query);
    $row = mysqli_fetch_array($run_query);
    $_SESSION["uid"] = $row["admin_id"];
    $_SESSION["name"] = $row["fname"];

    if(empty($email) || empty($password)){
        $_SESSION['error'] = 'Fill in the form first';
        header('location:login.php');
    }
    else{
        if ($count == 1){
            echo 'login_success';
            header('location: index.php');
        }
        else{
            $_SESSION['error'] = 'Incorrect login credentials';
            header('location:login.php');
        }
    }
}
//logout

if (isset($_POST['logout'])){
    unset($_SESSION['uid']);
    unset($_SESSION['name']);

    header('location:login.php');
}


//add user
if (isset($_POST['adduser'])) {
    $first = $_POST['firstname'];
    $last = $_POST['lastname'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $repassword = $_POST['repassword'];
    $subscription = $_POST['subscription'];
    $contact = $_POST['contact'];

    $date = date('Y-m-d');

    if (empty($first) || empty($last) || empty($email) || empty($password) || empty($repassword) || empty($subscription) || empty($contact)) {
        $_SESSION['error'] = 'Please fill in the form';
        header('location: users.php');

    } else {
        if (strlen($password) < 8) {
            $_SESSION['error'] = 'Password is weak';
            header('location: users.php');
            exit;
        }
        if ($password != $repassword) {
            $_SESSION['error'] = 'Passwords dont match';
            header('location: users.php');
            exit;
        }

        //existing email address in our database
        $sql = "SELECT user_id FROM users WHERE email = '$email' LIMIT 1";
        $check_query = mysqli_query($con, $sql);
        $count_email = mysqli_num_rows($check_query);
        if ($count_email > 0) {
            $_SESSION['error'] = 'Email already exists';
            header('location:users.php');

        } else {

            $sql = "INSERT INTO `users` 
		(`user_id`, `fname`, `lname`, `email`, 
		`password`,`subscription`,`contact`,`created_on`) 
		VALUES (NULL, '$first', '$last', '$email', 
		'$password','$subscription','$contact','$date')";
            $run_query = mysqli_query($con, $sql);

            if ($run_query) {
                $_SESSION['success'] = 'User has been registered successfully';
                header('location:users.php');
            }
            else{
                $_SESSION['error'] = 'User has not been registered successfully';
                header('location:users.php');
            }
            
        }
    }
}

// edit user
if (isset($_POST['edituser'])) {
    $id = $_POST['id'];
    $first = $_POST['firstname'];
    $last = $_POST['lastname'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $repassword = $_POST['repassword'];
    $subscription = $_POST['subscription'];
    $contact = $_POST['contact'];

    $date = date('Y-m-d');

    if (empty($first) || empty($last) || empty($email) || empty($password) || empty($repassword) || empty($subscription) || empty($contact)) {
        $_SESSION['error'] = 'Please fill in the form';
        header('location: users.php');

    } else {
        if (strlen($password) < 8) {
            $_SESSION['error'] = 'Password is weak';
            header('location: users.php');
            exit;
        }
        if ($password != $repassword) {
            $_SESSION['error'] = 'Passwords dont match';
            header('location: users.php');
            exit;
        }
        else {

            $sql = "UPDATE users SET `fname`= '$first',`lname` = '$last',`email` = '$email',`password` = '$password',`subscription`='$subscription',`contact`='$contact' WHERE user_id = '$id' ";

            $run_query = mysqli_query($con, $sql);

            if ($run_query) {
                $_SESSION['success'] = 'User has been updated successfully';
                header('location:users.php');
            }
            else{
                $_SESSION['error'] = 'User has not been updated successfully';
                header('location:users.php');
            }
        }
    }
}
//delete user
if (isset($_POST['deluser'])){
    $id = $_POST['id'];

    $sql= "DELETE FROM users WHERE user_id = '$id'";
    $query = mysqli_query($con,$sql);
    if ($query){
        $_SESSION['success'] = "User deleted successfully";
        header('location:users.php');
    }
    else{
        $_SESSION['error'] = 'User not deleted';
        header('location:users.php');
    }
}
