<!-- Edit pick-->
<div class="modal fade" id="editpick<?php echo $fetch['pick_id']?>">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edit Pick Id <?php echo $fetch['pick_id']?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" method="POST" action="action.php" enctype="multipart/form-data">
                    <div class="form-group">

                        <label for="match" class="col-sm-3 control-label">Match Id</label>

                        <div class="col-sm-5">
                            <input type="hidden" name="id" value="<?php echo $fetch ['pick_id']?>">
                            <select class="form-control" id="match" name="match" required>
                                <option value="<?php echo $match ?>"><?php echo "$hm vs $aw" ?></option>
                                <?php
                                $result=mysqli_query($con,"select * from game")or die ("query 1 incorrect.....");

                                while(list($id,$h,$a)=mysqli_fetch_array($result))
                                {
                                    $sql=mysqli_query($con,"select * from teams where team_id='$h'");
                                    $row = mysqli_fetch_array($sql); 
                                    $team1=$row['team_name'];

                                    $run_query=mysqli_query($con,"select * from teams where team_id='$a'");
                                    $get = mysqli_fetch_array($run_query); 
                                    $team2=$get['team_name'];

                                    echo "
                                    <option value='$id'>$team1 vs $team2</option>
                                   ";
                                }
                                ?>

                            </select>
                        </div>

                        <label for="tip" class="col-sm-3 control-label">Tips</label>

                        <div class="col-sm-5">
                            <select class="form-control" id="tip" name="tip" required>
                                <option value="<?php echo $tip ?>"><?php echo "$t" ?></option>
                                <?php
                                $result=mysqli_query($con,"select * from tips")or die ("query 1 incorrect.....");

                                while(list($id,$name)=mysqli_fetch_array($result))
                                {
                                    echo "
                                    <option value='$id'>$name</option>
                                ";
                                }
                                ?>

                            </select>
                        </div>
                    </div>

                    <label for="key" class="col-sm-3 control-label">Key Id</label>

                    <div class="col-sm-5">
                        <select class="form-control" id="sku" name="sku" required>
                            <option value="<?php echo $sku ?>"><?php echo $sku ?></option>
                            <?php
                            $result=mysqli_query($con,"select * from pk")or die ("query 1 incorrect.....");

                            while(list($id,$key)=mysqli_fetch_array($result))
                            {
                                echo "
                                <option value='$key'>$key</option>
                            ";
                            }
                            ?>

                        </select>
                    </div>

                    <div class="form-group">
                        <label for="odds" class="col-sm-3 control-label">Odds</label>

                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="odds" name="odds" value="<?php echo $odds ?>" required>
                        </div>
                    </div>
                   
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
                <button type="submit" class="btn btn-primary btn-flat" name="editpick"><i class="fa fa-save"></i> Save</button>
                </form>
            </div>
        </div>
    </div>
</div>





<!-- Delete pick -->
<div class="modal fade" id="deletepick<?php echo $fetch['pick_id']?>">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Delete Pick Id <?php echo $fetch['pick_id']?></h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Do you want to delete Pick Id <?php echo $fetch['pick_id']?>?</div>
            <div class="modal-footer">
                <form action="action.php" method="post">
                    <input type="hidden" name="id" value="<?php echo $fetch ['pick_id']?>">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <button class="btn btn-danger" type="submit" name="delpick">Delete</button>
                </form>

            </div>
        </div>
    </div>
</div>