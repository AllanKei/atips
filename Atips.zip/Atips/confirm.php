<?php
session_start();
if (!isset($_SESSION['uid'])){
    header('location:login.php');
}

include"includes/header.php";
include"db.php";
?>

<body data-spy="scroll" data-target="#pb-navbar" data-offset="200">



	<nav class="navbar navbar-expand-lg site-navbar navbar-light bg-light" id="pb-navbar">

		<div class="container">
            <div class="navbar-brand">
                <h2>ATIPS</h2>
            </div>

		</div>
	</nav>


	
	<section class="site-section " id="section-services">
        <div class="container">

			<div class="row justify-content-center">
                <?php

                    if(isset($_SESSION['error'])){
                        echo "
                            <div class='alert alert-danger text-center'>
                            <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                                <p>".$_SESSION['error']."</p> 
                            </div>
                            ";
                        unset($_SESSION['error']);
                    }

                    if(isset($_SESSION['success'])){
                        echo "
                            <div class='alert alert-success text-center'>
                            <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                                <p>".$_SESSION['success']."</p> 
                            </div>
                            ";
                        unset($_SESSION['success']);
                    }
                ?>
			</div>
		</div>
    </section> 
    <?php
    include"includes/scripts.php";
    ?>