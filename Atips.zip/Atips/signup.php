<?php
include"includes/header.php";
?>

<body data-spy="scroll" data-target="#pb-navbar" data-offset="200">

    <section class="site-section " id="section-services">
        <div class="container">

			<div class="row mb-4">
				<div class="col-md-12">
					<div class="section-heading text-center">
						<h2> <strong>Signup Form</strong></h2>
					</div>
				</div>
			</div>
			<div class="row justify-content-center">
				<div class="col-md-6 col-lg-5 text-center mb-5">
					<div class="site-service-item site-animate" data-animate-effect="fadeIn">
                        
                        <form class="site-form" action="action.php" method="post">
                            <h3 class="mb-5">Create Account!</h3>
                            <div class="form-group row">
                                <div class="col-sm-6 mb-3 mb-sm-0">
                                  <input type="text" class="form-control form-control-user" id="exampleFirstName" name="fname" placeholder="First Name">
                                </div>
                                <div class="col-sm-6">
                                  <input type="text" class="form-control form-control-user" id="exampleLastName" name="lname" placeholder="Last Name">
                                </div>
                              </div>
                              <div class="form-group">
                                <input type="email" class="form-control form-control-user" id="exampleInputEmail" name="email" placeholder="Email Address">
                              </div>
                              <div class="form-group row">
                                <div class="col-sm-6 mb-3 mb-sm-0">
                                  <input type="password" class="form-control form-control-user" id="exampleInputPassword" name="password" placeholder="Password">
                                </div>
                                <div class="col-sm-6">
                                  <input type="password" class="form-control form-control-user" id="exampleRepeatPassword" name="repass" placeholder="Confirm Password">
                                </div>
                              </div>
                              <div class="form-group">
                                <input type="number" class="form-control form-control-user" id="contact" name="contact" placeholder="Contact">
                              </div>
                            <input class="btn btn-primary btn-user btn-block" type="submit" name="signup" value="Signup">

                            <hr>
                            
						  </form>
							<div class="text-center">
								<a  href="login.php">Already have an account?Login!</a>
                            </div>
                            <div class="text-center">
								<a  href="index.php">Home</a>
							</div>

					</div>
				</div>
			</div>
		</div>
	</section> 

</body>
</html>