
		<!--footer-->
        <section class="footer">
            <div class="container center-text">
                <div class="row">
                    <div class="col-md-4">
                        <h1>Useful links</h1>
                        <p><a href="#">Privacy policy</a></p>
                        <p><a href="#">Disclaimer</a></p>
                        <p><a href="#">Terms & condition</a></p>
                    </div>
                    <div class="col-md-4">
						<h1>Follow us</h1>
						<div class="f-s">
							<p class="f-icons"><a href="#"><i class="icon-facebook"></i></a></p>
							<p class="f-icons"><a href="#"><i class="icon-youtube"></i></a></p>
							<p class="f-icons"><a href="#"><i class="icon-twitter"></i></a></p>
						</div>
                        
                    </div>
                    <div class="col-md-4">
                        <h1>Subscribe for new updates</h1>
                        <input type="text" class="form-control" placeholder="Enter your email">
                        <button class="btn btn-outline-success bt-sub">Subscribe</button>
                    </div>
                </div>
                <hr>
                <p class="copyright">@2020 || All rights reserved</p>
            </div>
        </section>
<!--end of footer-->
	</footer>