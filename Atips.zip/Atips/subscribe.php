<?php
session_start();
if (!isset($_SESSION['uid'])){
    header('location:login.php');
}

include"includes/header.php";
include"db.php";
?>

<body data-spy="scroll" data-target="#pb-navbar" data-offset="200">



	<nav class="navbar navbar-expand-lg site-navbar navbar-light bg-light" id="pb-navbar">

		<div class="container">
            <div class="navbar-brand">
                <h2>ATIPS</h2>
            </div>

		</div>
	</nav>


	
	<section class="site-section " id="section-services">
        <div class="container">

			<div class="row mb-4">
				<div class="col-md-12">
					<div class="section-heading text-center">
						<h2>Choose <strong>Subscription</strong></h2>
					</div>
				</div>
			</div>
			<div class="row">
                <?php
                    $query = mysqli_query($con, "SELECT * FROM subscription") or die(mysqli_error());
                    while($fetch = mysqli_fetch_array($query)){
                        $sub=$fetch['sub_id'];
                        $type=$fetch['type'];
                        $price=$fetch['price'];
                        echo'
                        <div class="col-md-6 col-lg-4 text-center mb-5">
					        <div class="site-service-item site-animate" data-animate-effect="fadeIn">
                                <span class="icon">
                                    <span class="icon-wallet2"></span>
                                </span>
                                <h3 class="mb-4">'.$type.'</h3>
                                <p>Ksh '.$price.'</p>
                                <p><a href="pay.php?id='.$sub.'" class="site-link">Subscribe <i class="icon-chevron-right"></i></a></p>
					        </div>
                        </div>
                        ';
                    
                    }
                ?>
			</div>
		</div>
    </section> 
    <?php
    include"includes/scripts.php";
    ?>